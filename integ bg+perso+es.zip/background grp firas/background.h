#ifndef BACKGROUND_H
#define BACKGROUND_H

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#define LONGEUR_ECRAN 800
#define LARGEUR_ECRAN 1000

typedef struct {
    SDL_Surface *spriteSheet;
    SDL_Rect Clips[8];
    int frames;
    int clipLoaded;
} animation;

typedef struct {
    animation animation;
    SDL_Surface *image[6];
    int currentStage;
    SDL_Rect camera;
    SDL_Rect camera2; 
    SDL_Rect posEcran1;
    SDL_Rect posEcran2;
    Mix_Music *music;
    Mix_Music *music2;
    int clipLoaded2;
} background;

typedef struct {
    char name[20];
    int score;
    int temps;
} Score;



void initialisation(background *b);
void affichagebackground(background b, SDL_Surface *ecrans);
void scro(background *b, int numBAck, int direction, int pasAvancement);
void Animation(background *b, int temps);

void save_score(Score score);
void bestscore(SDL_Surface *ecrans,SDL_Surface *screen);
void display_zqsd(SDL_Surface *screen, int startTime) ;
void display_arrows(SDL_Surface *screen, int startTime);

#endif /* BACKGROUND_H */

