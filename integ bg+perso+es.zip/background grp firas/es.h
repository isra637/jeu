#ifndef ES
#define ES
#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
typedef struct
{
    SDL_Surface *spriteSheet[3]; // 1: right 0:left
    SDL_Rect Clips[8];
    int side; // 1: right 2: left 0: dead
    int frames;
    int clipLoaded;
} Animation_enemy;

typedef struct
{
    SDL_Rect pos; // position mtaa el enemie
    Animation_enemy Animation_enemy;
    int col; // 0: non colusion 1: colusion
} Enemy;

void generate_Clips(SDL_Rect Clips[8], int frames, int frameWidth, int clipWidth, int clipHeight);
void apply_surface(int x, int y, SDL_Surface *source, SDL_Surface *destination);
void initialize_Enemy(Enemy *e);
void initialize_Enemy1(Enemy *e);
void initialize_Enemy_second(Enemy *e);
void display_Enemy(Enemy e, SDL_Surface *screen);
void animate_Enemy(Enemy *e);
void move(Enemy *e);
int collisionBB(SDL_Rect CharacterPos, SDL_Rect EnemyPos);
int collisionTri(SDL_Rect CharacterPos, SDL_Rect EnemyPos);
void freeEnemy(Enemy e);
void moveAI(Enemy *e, SDL_Rect posPerso);
void freeEnemyY(Enemy *e);

#endif /* ES */
