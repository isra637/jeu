#include "background.h"
#include <SDL/SDL_mixer.h>
#include <errno.h> 
void initialisation(background *b) {
    int i, w;
    b->image[0] = IMG_Load("stage.png");
    b->image[1] = IMG_Load("stage.png");

    // Camera 1 (Top part of the screen, scrolling up)
    b->camera.x = 0;
    b->camera.y = 0; 
    b->camera.h = 400; // top part
    b->camera.w = 1000; 

    // Camera 2 (Bottom part of the screen, scrolling down)
    b->camera2.x = 0;
    b->camera2.y = 0; 
    b->camera2.h = 400; // bottom part
    b->camera2.w = 1000; 

    // Positions on screen
    b->posEcran1.x = 0;
    b->posEcran1.y = 0;
    b->posEcran1.w = 1000;
    b->posEcran1.h = 400;

    b->posEcran2.x = 0;
    b->posEcran2.y = 400;
    b->posEcran2.w = 1000;
    b->posEcran2.h = 400;

    b->currentStage = 0;

    b->animation.frames = 4;
    b->animation.clipLoaded = 0;
    b->clipLoaded2 = 0; 

    for (i = 0, w = 0; i < b->animation.frames; i++, w += 120) {
        b->animation.Clips[i].w = 110;
        b->animation.Clips[i].h = 300;
        b->animation.Clips[i].x = w;
        b->animation.Clips[i].y = 0;
    }
}

void affichagebackground(background b, SDL_Surface *ecrans) {
    SDL_BlitSurface(b.image[b.currentStage], &b.camera, ecrans, &b.posEcran1);
    SDL_BlitSurface(b.animation.spriteSheet, &b.animation.Clips[b.clipLoaded2], ecrans, NULL);
    SDL_BlitSurface(b.image[b.currentStage], &b.camera2, ecrans, &b.posEcran2);
}

void Animation(background *b, int temps) {
    if (temps % 2 == 0) {
        b->animation.clipLoaded++;
    }
    if (b->animation.clipLoaded >= b->animation.frames) {
        b->animation.clipLoaded = 0;
    }

    if (temps % 2 == 0) {
        b->clipLoaded2++;
    }
    if (b->clipLoaded2 >= b->animation.frames) {
        b->clipLoaded2 = 0;
    }
}

// New version: scrolling up for top part and scrolling down for bottom part
void scro(background *b, int numBack, int direction, int pasAvancement) {
    SDL_Rect *camera;
    if (numBack == 1) {
        camera = &b->camera; // Top half (scroll up)
    } else if (numBack == 2) {
        camera = &b->camera2; // Bottom half (scroll down)
    } else {
        return;
    }

    switch (direction) {
        case 1: // scroll up (top)
            if (camera->x > 0)
                camera->x -= pasAvancement;
            break;
        case 2: // scroll down (bottom)
            camera->x += pasAvancement;
            break;
    }

    if (camera->y > 1000) {
        Mix_HaltMusic();
        Mix_PlayMusic(b->music2, -1);
    }
}


void save_score(Score score) {
       Score scores[1000];
    int count = 0, found = 0;
    FILE *fp = fopen("score.txt", "r");

    // If the file exists, read all current score records.
    if (fp != NULL) {
        while (count < 1000 && fscanf(fp, "%s %d %d", 
               scores[count].name, &scores[count].score, &scores[count].temps) != EOF) {
            count++;
        }
        fclose(fp);
    }

    // Check if newScore.name already exists.
    for (int i = 0; i < count; i++) {
        if (strcmp(scores[i].name, score.name) == 0) {
            // Update the record (you could also choose to update only if newScore is better)
            scores[i] = score;
            found = 1;
            break;
        }
    }
    
    // If not found and there is space, add the new record.
    if (!found && count < 1000) {
        scores[count++] = score;
    }

    // Write the updated list back to the file.
    fp = fopen("score.txt", "w");
    if (fp == NULL) {
        printf("Error opening score file for writing: %s\n", strerror(errno));
        return;
    }
    for (int i = 0; i < count; i++) {
        fprintf(fp, "%s %d %d\n", scores[i].name, scores[i].score, scores[i].temps);
    }
    fclose(fp);
}

// Function to display the best scores
void bestscore(SDL_Surface *ecrans, SDL_Surface *screen) {
    TTF_Font *font;
    SDL_Color textColor = {0, 0, 0};  // Black color for the text
    SDL_Surface *textSurface;
    SDL_Rect textPos;
    char scoreStr[30];
    Score scores[1000] = {0};
    int i, j;
    FILE *fp;

    font = TTF_OpenFont("font.ttf", 28);
    if (font == NULL) {
        printf("Error opening font: %s\n", TTF_GetError());
        return;
    }

    fp = fopen("score.txt", "r");
    if (fp == NULL) {
        printf("Error opening file: %s\n", strerror(errno));
        return;
    }

    // Read scores from the file
    for (i = 0; i < 1000; i++) {
        if (fscanf(fp, "%s %d %d", scores[i].name, &scores[i].score, &scores[i].temps) == EOF) {
            printf("Read %d scores\n", i);  // Debugging output
            break;
        }
    }
    fclose(fp);

    // Sort the scores in descending order
    for (i = 0; i < 999; i++) {
        for (j = i + 1; j < 1000; j++) {
            if (scores[j].score > scores[i].score ||
               (scores[j].score == scores[i].score && scores[j].temps > scores[i].temps)) {
                Score aux = scores[i];
                scores[i] = scores[j];
                scores[j] = aux;
            }
        }
    }

    // Display top 3 scores
    for (i = 0; i < 3; i++) {
        sprintf(scoreStr, "%d/ %s: %d", i + 1, scores[i].name, scores[i].score);
        textSurface = TTF_RenderText_Solid(font, scoreStr, textColor);
        textPos.x = 50;  // Start X position
        textPos.y = 100 + i * 50;  // Adjust Y for spacing
        SDL_BlitSurface(textSurface, NULL, screen, &textPos);
        SDL_FreeSurface(textSurface);
    }

    SDL_Flip(screen);  // To update the display in SDL 1.2
    //SDL_Delay(1000);  // Display the scores for 2.5 seconds

    TTF_CloseFont(font);
}


void display_timer(SDL_Surface *screen, int startTime) {
    TTF_Font *font;
    SDL_Color textColor = {255, 255, 255};  // white color for the timer
    SDL_Surface *textSurface;
    SDL_Rect textPos;
    char timerStr[30];
    int elapsedTime = (SDL_GetTicks() / 1000) - startTime;  // Elapsed time in seconds

    // Convert elapsed time to minutes and seconds
    int minutes = elapsedTime / 60;
    int seconds = elapsedTime % 60;

    // Format the time string (e.g., "Time: 01:23")
    sprintf(timerStr, "Time: %02d:%02d", minutes, seconds);

    // Load font and render the timer text
    font = TTF_OpenFont("font.ttf", 28);  // Ensure you have a valid font file
    if (font == NULL) {
        printf("Error opening font\n");
        return;
    }

    textSurface = TTF_RenderText_Solid(font, timerStr, textColor);
    textPos.x = 10;  // Position the timer at the top-left corner
    textPos.y = 10;

    // Display the timer on the screen
    SDL_BlitSurface(textSurface, NULL, screen, &textPos);
    SDL_FreeSurface(textSurface);

    TTF_CloseFont(font);
}


void display_zqsd(SDL_Surface *screen, int startTime) {
     static SDL_Surface *zqsdImage = NULL;
    static TTF_Font *font = NULL;
    static int isInitialized = 0;
    SDL_Rect zqsdPos, textPos;
    int elapsedTime = SDL_GetTicks() - startTime;

    // Load the image and font only once
    if (!isInitialized) {
        zqsdImage = IMG_Load("zqsd.jpg");
        if (zqsdImage == NULL) {
            printf("Error loading zqsd.png: %s\n", IMG_GetError());
            return;
        }

        font = TTF_OpenFont("font.ttf", 24);
        if (font == NULL) {
            printf("Error loading font: %s\n", TTF_GetError());
            return;
        }

        isInitialized = 1;
    }

    if (elapsedTime >= 3000 && elapsedTime <= 7000) {
        // Set manual position for image
        zqsdPos.x = 100; // 
        zqsdPos.y = 200;

        // Render text surface
        SDL_Color white = {255, 255, 255};
        SDL_Surface *textSurface = TTF_RenderText_Solid(font, "This is the movement keys - Player 1", white);
        if (textSurface) {
            textPos.x = zqsdPos.x + (zqsdImage->w - textSurface->w) / 2; // Center text above image
            textPos.y = zqsdPos.y - textSurface->h - 10;

            SDL_BlitSurface(textSurface, NULL, screen, &textPos);
            SDL_FreeSurface(textSurface);
        }

        SDL_BlitSurface(zqsdImage, NULL, screen, &zqsdPos);
    }
}


void display_arrows(SDL_Surface *screen, int startTime) {
    static SDL_Surface *zqsdImage = NULL;
    static TTF_Font *font = NULL;
    static int isInitialized = 0;
    SDL_Rect zqsdPos, textPos;
    int elapsedTime = SDL_GetTicks() - startTime;

    // Load the image and font only once
    if (!isInitialized) {
        zqsdImage = IMG_Load("arrows.jpg");
        if (zqsdImage == NULL) {
            printf("Error loading zqsd.png: %s\n", IMG_GetError());
            return;
        }

        font = TTF_OpenFont("font.ttf", 24);
        if (font == NULL) {
            printf("Error loading font: %s\n", TTF_GetError());
            return;
        }

        isInitialized = 1;
    }

    if (elapsedTime >= 3000 && elapsedTime <= 7000) {
        // Set manual position for image
        zqsdPos.x = 100; // 
        zqsdPos.y = 600;

        // Render text surface
        SDL_Color white = {255, 255, 255};
        SDL_Surface *textSurface = TTF_RenderText_Solid(font, "This is the movement keys - Player 2", white);
        if (textSurface) {
            textPos.x = zqsdPos.x + (zqsdImage->w - textSurface->w) / 2; // Center text above image
            textPos.y = zqsdPos.y - textSurface->h - 10;

            SDL_BlitSurface(textSurface, NULL, screen, &textPos);
            SDL_FreeSurface(textSurface);
        }

        SDL_BlitSurface(zqsdImage, NULL, screen, &zqsdPos);
    }
}
