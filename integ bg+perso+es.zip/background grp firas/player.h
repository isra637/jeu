#ifndef PLAYER_H
#define PLAYER_H

#include <SDL/SDL.h>
#include <stdbool.h>

#define MAX_LIVES 3
#define GRAVITY 0.5
#define JUMP_FORCE -12
#define WALK_SPEED 1

typedef enum {
    IDLE,
    WALKING,
    JUMPING,
    ATTACKING
} PlayerState;

typedef struct {
    SDL_Surface *sprite_sheet;
    SDL_Rect position;
    SDL_Rect *animation_frames;
    int frame_count;
    int current_frame;
    float frame_delay;
    float frame_timer;
    
    float velocity_x;
    float velocity_y;
    bool is_grounded;
    PlayerState state;
    int direction; // 1 = droite, -1 = gauche
    
    int lives;
    int score;
} Player;

void init_player(Player *player, const char *sprite_path, int x, int y);
void load_animation_frames(Player *player, int frame_width, int frame_height, int cols, int rows);
void update_player(Player *player, float delta_time);
void update_player_2(Player *player, float delta_time);
void handle_input(Player *player, const Uint8 *keys);
void handle_input_player_2(Player *player, const Uint8 *keys);
void draw_player(Player *player, SDL_Surface *screen);
void free_player(Player *player);
void load_animation_framese(Player *enemy, int frame_width, int frame_height, int cols, int rows);

#endif
