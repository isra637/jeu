#include "player.h"
#include <SDL/SDL_image.h>
#include <stdio.h>
#include <stdlib.h>

#define MAX_LIVES 3

void init_player(Player *player, const char *sprite_path, int x, int y) {
    player->sprite_sheet = IMG_Load(sprite_path);
    if (!player->sprite_sheet) {
        printf("Erreur chargement sprite sheet: %s\n", IMG_GetError());
        return;
    }

    player->position.x = x;
    player->position.y = y;
    player->position.w = 256;
    player->position.h = 341;

    player->velocity_x = 0;
    player->velocity_y = 0;
    player->is_grounded = 0;
    player->direction = 1;

    player->animation_frames = NULL;
    player->frame_count = 0;
    player->current_frame = 0;
    player->frame_delay = 0.1f;
    player->frame_timer = 0;

    player->lives = MAX_LIVES;
    player->score = 0;
    player->state = IDLE;
}

void load_animation_frames(Player *player, int frame_width, int frame_height, int cols, int rows) {
    player->frame_count = cols * rows;
    player->animation_frames = malloc(sizeof(SDL_Rect) * player->frame_count);

    player->position.w = frame_width;
    player->position.h = frame_height;

    for (int y = 0; y < rows; y++) {
        for (int x = 0; x < cols; x++) {
            int index = y * cols + x;
            player->animation_frames[index].x = x * 72;
            player->animation_frames[index].y = 2 * 101;
            player->animation_frames[index].w = 60;
            player->animation_frames[index].h = 72;
        }
    }
}

void load_animation_framese(Player *enemy, int frame_width, int frame_height, int cols, int rows) {
    enemy->frame_count = cols * rows;
    enemy->animation_frames = malloc(sizeof(SDL_Rect) * enemy->frame_count);

    enemy->position.w = frame_width;
    enemy->position.h = frame_height;

    for (int y = 0; y < rows; y++) {
        for (int x = 0; x < cols; x++) {
            int index = y * cols + x;
            enemy->animation_frames[index].x = x * 63;
            enemy->animation_frames[index].y = 2 * 101;
            enemy->animation_frames[index].w = 48;
            enemy->animation_frames[index].h = 100;
        }
    }
}

void update_player(Player *player, float delta_time) {
    if (!player->is_grounded) {
        player->velocity_y += GRAVITY;
    }

    player->position.x += player->velocity_x;
    player->position.y += player->velocity_y;

    player->frame_timer += delta_time;
    if (player->frame_timer >= player->frame_delay) {
        player->frame_timer = 0;
        player->current_frame = (player->current_frame + 1) % player->frame_count;
    }

    if (player->position.y >= 200) {
        player->position.y = 200;
        player->is_grounded = 1;
        player->velocity_y = 0;
        if (player->state == JUMPING)
            player->state = IDLE;
    } else {
        player->is_grounded = 0;
    }

    if (player->velocity_x != 0 && player->is_grounded) {
        player->state = WALKING;
    } else if (player->is_grounded && player->state != ATTACKING) {
        player->state = IDLE;
    }
}


void update_player_2(Player *player, float delta_time) {
    if (!player->is_grounded) {
        player->velocity_y += GRAVITY;
    }

    player->position.x += player->velocity_x;
    player->position.y += player->velocity_y;

    player->frame_timer += delta_time;
    if (player->frame_timer >= player->frame_delay) {
        player->frame_timer = 0;
        player->current_frame = (player->current_frame + 1) % player->frame_count;
    }

    if (player->position.y >= 600) {
        player->position.y = 600;
        player->is_grounded = 1;
        player->velocity_y = 0;
        if (player->state == JUMPING)
            player->state = IDLE;
    } else {
        player->is_grounded = 0;
    }

    if (player->velocity_x != 0 && player->is_grounded) {
        player->state = WALKING;
    } else if (player->is_grounded && player->state != ATTACKING) {
        player->state = IDLE;
    }
}

void handle_input(Player *player, const Uint8 *keys) {
    player->velocity_x = 0;

    if (keys[SDLK_RIGHT]) {
        player->velocity_x = WALK_SPEED;
        player->direction = 1;
    }
    if (keys[SDLK_LEFT]) {
        player->velocity_x = -WALK_SPEED;
        player->direction = -1;
    }
    if (keys[SDLK_UP] && player->is_grounded) {
        player->velocity_y = JUMP_FORCE;
        player->is_grounded = 0;
        player->state = JUMPING;
    }
    if (keys[SDLK_SPACE]) {
        player->state = ATTACKING;
        player->current_frame = 0;
    }
}

void handle_input_player_2(Player *player, const Uint8 *keys) {
    player->velocity_x = 0;

    if (keys[SDLK_d]) {
        player->velocity_x = WALK_SPEED;
        player->direction = 1;
    }
    if (keys[SDLK_q]) {
        player->velocity_x = -WALK_SPEED;
        player->direction = -1;
    }
    if (keys[SDLK_z] && player->is_grounded) {
        player->velocity_y = JUMP_FORCE;
        player->is_grounded = 0;
        player->state = JUMPING;
    }
    if (keys[SDLK_RETURN]) {
        player->state = ATTACKING;
        player->current_frame = 0;
    }
}

void draw_player(Player *player, SDL_Surface *screen) {

    SDL_Rect src_rect = player->animation_frames[player->current_frame];
    SDL_Rect dest_rect = player->position;

    if (player->direction == -1) {
        SDL_Surface *flipped = SDL_CreateRGBSurface(SDL_SWSURFACE, src_rect.w, src_rect.h,
            player->sprite_sheet->format->BitsPerPixel,
            player->sprite_sheet->format->Rmask,
            player->sprite_sheet->format->Gmask,
            player->sprite_sheet->format->Bmask,
            player->sprite_sheet->format->Amask);

        SDL_LockSurface(player->sprite_sheet);
        SDL_LockSurface(flipped);

        Uint32 *pixels = (Uint32 *)player->sprite_sheet->pixels;
        Uint32 *flipped_pixels = (Uint32 *)flipped->pixels;

        for (int y = 0; y < src_rect.h; y++) {
            for (int x = 0; x < src_rect.w; x++) {
                flipped_pixels[y * src_rect.w + (src_rect.w - 1 - x)] =
                    pixels[(src_rect.y + y) * player->sprite_sheet->w + (src_rect.x + x)];
            }
        }

        SDL_UnlockSurface(flipped);
        SDL_UnlockSurface(player->sprite_sheet);

        SDL_BlitSurface(flipped, NULL, screen, &dest_rect);
        SDL_FreeSurface(flipped);
    } else {
        SDL_BlitSurface(player->sprite_sheet, &src_rect, screen, &dest_rect);
    }
}

void free_player(Player *player) {
    if (player->sprite_sheet) {
        SDL_FreeSurface(player->sprite_sheet);
    }
    if (player->animation_frames) {
        free(player->animation_frames);
    }
}

