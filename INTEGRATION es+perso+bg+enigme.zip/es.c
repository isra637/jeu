#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <math.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include "es.h"

void generate_Clips(SDL_Rect Clips[8], int frames, int frameWidth, int clipWidth, int clipHeight)
{
    int i, w;
    for (w = 0, i = 0; i < frames; i++, w += frameWidth)
    { 
        Clips[i].x = w;
        Clips[i].y = 0;
        Clips[i].w = clipWidth;  
        Clips[i].h = clipHeight; 
    }
}
void apply_surface(int x, int y, SDL_Surface *source, SDL_Surface *destination)
{
    SDL_Rect offset; 
    offset.x = x;
    offset.y = y;
    SDL_BlitSurface(source, NULL, destination, &offset);
}

void initialize_Enemy(Enemy *e)
{
    e->pos.x = 500;
    e->pos.y = 560;
    e->pos.w = 209;
    e->pos.h = 149;
    e->col = 0;
    e->Animation_enemy.spriteSheet[0] = IMG_Load("spritesheet/leftsheet.png");
    e->Animation_enemy.spriteSheet[1] = IMG_Load("spritesheet/rightsheet.png");
    e->Animation_enemy.frames = 3;
    e->Animation_enemy.side = 1;
    e->Animation_enemy.clipLoaded = 0;
    generate_Clips(e->Animation_enemy.Clips, e->Animation_enemy.frames, 230, 160, 149);
}

void initialize_Enemy_second(Enemy *e)
{
    e->pos.x = 500;
    e->pos.y = 180;
    e->pos.w = 209;
    e->pos.h = 149;
    e->col = 0;
    e->Animation_enemy.spriteSheet[0] = IMG_Load("spritesheet/leftsheet.png");
    e->Animation_enemy.spriteSheet[1] = IMG_Load("spritesheet/rightsheet.png");
    e->Animation_enemy.frames = 3;
    e->Animation_enemy.side = 1;
    e->Animation_enemy.clipLoaded = 0;
    generate_Clips(e->Animation_enemy.Clips, e->Animation_enemy.frames, 230, 160, 149);
}
void initialize_Enemy1(Enemy *e)
{
    e->pos.x = 150;
    e->pos.y = 450;
    e->pos.w = 300;
    e->pos.h = 484;
    e->col = 0;
    e->Animation_enemy.spriteSheet[0] = IMG_Load("spritesheet/coin.png");
    e->Animation_enemy.spriteSheet[1] = IMG_Load("spritesheet/coin.png");
    e->Animation_enemy.frames = 4;
    e->Animation_enemy.side = 1;
    e->Animation_enemy.clipLoaded = 0;
    generate_Clips(e->Animation_enemy.Clips, e->Animation_enemy.frames, 10, 500, 500); 
}

void display_Enemy(Enemy e, SDL_Surface *screen)
{
    SDL_BlitSurface(e.Animation_enemy.spriteSheet[e.Animation_enemy.side], &e.Animation_enemy.Clips[e.Animation_enemy.clipLoaded], screen, &e.pos);
}

void animate_Enemy(Enemy *e)
{
    if (SDL_GetTicks() % 4 == 0)
    {
        e->Animation_enemy.clipLoaded++;                          
        if (e->Animation_enemy.clipLoaded >= e->Animation_enemy.frames)
            e->Animation_enemy.clipLoaded = 0;                    
    }
}

void move(Enemy *e)
{
    if (e->Animation_enemy.side == 1) 
    {
        e->pos.x += 3;      
        if (e->pos.x >= 1200) 
            e->Animation_enemy.side = 0;
        animate_Enemy(e);
    }
    else if (e->Animation_enemy.side == 0)
    {
        e->pos.x -= 3;            
        if (e->pos.x <= 500)       
            e->Animation_enemy.side = 1; 
        animate_Enemy(e);
    }
}



void freeEnemy(Enemy e)
{
    SDL_FreeSurface(e.Animation_enemy.spriteSheet[0]); 
    SDL_FreeSurface(e.Animation_enemy.spriteSheet[1]);
}

void moveAI(Enemy *e, SDL_Rect charPos)
{
    int diff = e->pos.x - charPos.x;
    if (diff > 100 && diff < 200 && e->pos.x >= 400)
    {
        e->pos.x -= 15;
        e->Animation_enemy.side = 0;
        animate_Enemy(e);
    }
    else if (diff < -200 && diff > -400 && e->pos.x <= 1200)
    {
        e->pos.x += 15;
        e->Animation_enemy.side = 1;
        animate_Enemy(e);
    }
    else if (diff >= 50 && diff <= 100)
    {
        e->Animation_enemy.clipLoaded = 0;
        return;
    }
    else if (diff <= -150 && diff >= -200)
    {
        e->Animation_enemy.clipLoaded = 0;
        return;
    }
    else
    {
        move(e);
    }
}
int collisionTri(SDL_Rect CharacterPos, SDL_Rect EnemyPos)
{
  if (
        CharacterPos.x < EnemyPos.x + EnemyPos.w 
        && CharacterPos.x + CharacterPos.w > EnemyPos.x
        && CharacterPos.y < EnemyPos.y + EnemyPos.h
        && CharacterPos.h + CharacterPos.y > EnemyPos.y)
    {
        return 1; 
    }
    else
    {
        return 0; 
    }
}

int collisionBB(SDL_Rect CharacterPos, SDL_Rect EnemyPos)
{
    if (
        CharacterPos.x < EnemyPos.x + EnemyPos.w 
        && CharacterPos.x + CharacterPos.w > EnemyPos.x
        && CharacterPos.y < EnemyPos.y + EnemyPos.h
        && CharacterPos.h + CharacterPos.y > EnemyPos.y)
    {
  
        return 1; 
          
    }
    else
    {
        return 0; 
    }
}

void freeEnemyY(Enemy *e)
{
    SDL_FreeSurface(e->Animation_enemy.spriteSheet[0]); 
    SDL_FreeSurface(e->Animation_enemy.spriteSheet[1]);
    e->Animation_enemy.spriteSheet[0] = NULL; // Set surface pointers to NULL after freeing
    e->Animation_enemy.spriteSheet[1] = NULL;
    e->Animation_enemy.side = 0; // Set side to 0 indicating "dead" state
}







