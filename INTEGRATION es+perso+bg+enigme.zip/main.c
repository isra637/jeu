#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "background.h"
#include "player.h"
#include "es.h"
#include <SDL/SDL_mixer.h>
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include "header.h"
#define FPS 60

int main(int argc, char const *argv[]) {
    SDL_Surface *screen = NULL;
    SDL_Event event;
    int play = 0;
    int startTime;
    int temps = 0;
    char nom[30];

    // Initialize SDL and subsystems
    if (SDL_Init(SDL_INIT_EVERYTHING) < 0) {
        printf("Erreur lors de l'initialisation de SDL : %s\n", SDL_GetError());
        return 1;
    }
    if (TTF_Init() < 0) {
        printf("Erreur lors de l'initialisation de TTF : %s\n", TTF_GetError());
        SDL_Quit();
        return 1;
    }
    if (Mix_OpenAudio(48000, MIX_DEFAULT_FORMAT, 2, 4096) < 0) {
        printf("Erreur lors de l'initialisation de l'audio : %s\n", Mix_GetError());
        TTF_Quit();
        SDL_Quit();
        return 1;
    }

    Mix_Init(MIX_INIT_MP3 | MIX_INIT_OGG);

    screen = SDL_SetVideoMode(LARGEUR_ECRAN, LONGEUR_ECRAN, 32, SDL_SWSURFACE);
    if (screen == NULL) {
        printf("Erreur lors de la création de la surface d'affichage : %s\n", SDL_GetError());
        Mix_CloseAudio();
        TTF_Quit();
        SDL_Quit();
        return 1;
    }

    printf("Taper votre nom, s'il vous plaît !!!!!!: ");
    scanf("%s", nom);

    // Initialize background and music
    background b;
    initialisation(&b);
    b.music = Mix_LoadMUS("music1.mp3");
    b.music2 = Mix_LoadMUS("music2.mp3");
    if (!b.music || !b.music2) {
        printf("Erreur lors du chargement de la musique : %s\n", Mix_GetError());
        Mix_CloseAudio();
        TTF_Quit();
        SDL_Quit();
        return 1;
    }

    startTime = SDL_GetTicks();

    // Init players
    Player player, enemy;
    Uint32 last_time = SDL_GetTicks();
    init_player(&player, "img.png", 100, 100);
    init_player(&enemy, "img1.png", 100, 500);
    load_animation_frames(&player, 64, 64, 4, 4);
    load_animation_framese(&enemy, 64, 64, 11, 4);

    ///////////////////////////////////////////////////enemy////////////////////////
    Enemy e, e_other;
    Enemy e1;
 
    SDL_Rect playerRect;
    playerRect.x = 0;
    playerRect.y = 520;
    playerRect.w = 100; // Reducing player's width
    playerRect.h = 100; // Reducing player's height

    initialize_Enemy(&e);
    initialize_Enemy1(&e1);
    initialize_Enemy_second(&e_other);
    
    TTF_Font *font = TTF_OpenFont("Retro.ttf", 20); // Load font
    SDL_Color textColor = {255, 255, 255}; // White color for text
    SDL_Surface *textSurface = NULL;

    // Game loop
    while (!play) {
        temps = SDL_GetTicks() / 1000;
        Uint32 current_time = SDL_GetTicks();
        float delta_time = (current_time - last_time) / 1000.0f;
        last_time = current_time;

        // Enemy collision handling
        if (collisionTri(e1.pos, playerRect) == 1) {
            freeEnemyY(&e1);
        }
        if (collisionBB(e.pos, playerRect) == 1) {
            playerRect.x = 0;
        }

        moveAI(&e, playerRect);
        moveAI(&e_other, playerRect);

        // Event handling
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                //mainenigme();  // Call mainenigme when the SDL_QUIT event occurs
                play = 1;  // Set play to 1 to exit the game loop
            } else if (event.type == SDL_KEYDOWN) {
                switch (event.key.keysym.sym) {
                    case SDLK_SPACE: Mix_HaltMusic(); break;
                    case SDLK_z: scro(&b, 1, 3, 30); break;
                    case SDLK_s: scro(&b, 1, 4, 30); break;
                    case SDLK_d: scro(&b, 1, 2, 30); break;
                    case SDLK_q: scro(&b, 1, 1, 30); break;
                    case SDLK_UP: scro(&b, 2, 3, 30); break;
                    case SDLK_DOWN: scro(&b, 2, 4, 30); break;
                    case SDLK_RIGHT: scro(&b, 2, 2, 30); break;
                    case SDLK_LEFT: scro(&b, 2, 1, 30); break;
                    case SDLK_TAB: bestscore(screen, screen); break;
                }
            }
        }

        const Uint8 *keys = SDL_GetKeyState(NULL);
        handle_input(&enemy, keys);
        handle_input_player_2(&player, keys);

        update_player(&player, delta_time);
        update_player_2(&enemy, delta_time);

        int player_sprite_width = 64; // use actual width of player's sprite
        int enemy_sprite_width = 64;  // use actual width of enemy's sprite
        int background_width = 1515;

        // === PLAYER BOUNDS ===
        if (player.position.x < 0)
            player.position.x = 0;
        else if (player.position.x > background_width - player_sprite_width)
            player.position.x = background_width - player_sprite_width;

        // === ENEMY BOUNDS ===
        if (enemy.position.x < 0)
            enemy.position.x = 0;
        else if (enemy.position.x > background_width - enemy_sprite_width)
            enemy.position.x = background_width - enemy_sprite_width;
           

        // === CAMERA SCROLLING ===
        if ((player.position.x >= 250 && b.camera.x < background_width - b.camera.w) || 
            (enemy.position.x >= 250 && b.camera2.x < background_width - b.camera2.w)) {
           
            if (player.position.x >= 250) b.camera.x += 5;
            if (enemy.position.x >= 250) b.camera2.x += 5;
        }

        // === CAMERA LIMITS ===
        if (b.camera.x < 0) b.camera.x = 0;
        else if (b.camera.x > background_width - b.camera.w) b.camera.x = background_width - b.camera.w;

        if (b.camera2.x < 0) b.camera2.x = 0;
        else if (b.camera2.x > background_width - b.camera2.w) b.camera2.x = background_width - b.camera2.w;



 if (player.position.x >= 500)
 {
 mainenigme();
 }


        // === Music loop ===
        if (Mix_PlayingMusic() == 0) {
            Mix_PlayMusic(b.music, -1);
        }

        // === Clear screen ===
        SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 255, 255, 255)); // Clear screen

        // === Draw everything ===
        affichagebackground(b, screen);          // Draw background
        Animation(&b, temps);                    // Animate background

        display_Enemy(e, screen);               // Draw enemy 1
        // display_Enemy(e1, screen);              // Draw enemy 2
        display_Enemy(e_other, screen); 

        draw_player(&enemy, screen);            // Draw enemy player
        draw_player(&player, screen);           // Draw main player

        display_timer(screen, startTime / 1000);  // Show timer
        display_zqsd(screen, startTime);         // Show ZQSD controls
        display_arrows(screen, startTime);       // Show arrow controls

        SDL_Flip(screen);                       // Update the screen
    }

    // Save score after the game ends
    Score newScore;
    strncpy(newScore.name, nom, sizeof(newScore.name) - 1);
    newScore.name[sizeof(newScore.name) - 1] = '\0';
    newScore.score = 1000;
    newScore.temps = (SDL_GetTicks() / 1000) - (startTime / 1000);
    save_score(newScore);

    // Cleanup
    free_player(&player);
    free_player(&enemy);
    SDL_FreeSurface(b.image[0]);
    SDL_FreeSurface(b.image[1]);
    SDL_FreeSurface(b.animation.spriteSheet);
    Mix_FreeMusic(b.music);
    Mix_FreeMusic(b.music2);
    Mix_CloseAudio();
    TTF_Quit();
    SDL_FreeSurface(screen);
    SDL_Quit();

    return 0;
}

