#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include "header.h"

Enigme enigmes[MAX_QUESTIONS];
int total_questions = 0;
void display_background_and_button(SDL_Surface *screen) {
    // Charger le background
    SDL_Surface *background = IMG_Load("pg.png");
    if (!background) {
        fprintf(stderr, "Erreur de chargement du background: %s\n", IMG_GetError());
        return;
    }

    // Charger le bouton
    SDL_Surface *button = IMG_Load("q.png");
    if (!button) {
        fprintf(stderr, "Erreur de chargement du bouton: %s\n", IMG_GetError());
        SDL_FreeSurface(background);
        return;
    }

    // Afficher le background
    SDL_BlitSurface(background, NULL, screen, NULL);

    // Définir la position du bouton (en bas à droite)
    SDL_Rect button_pos;
    button_pos.x = screen->w - button->w - 20;
    button_pos.y = screen->h - button->h - 20;
    SDL_BlitSurface(button, NULL, screen, &button_pos);

    // Rafraîchir l'écran
    SDL_Flip(screen);

    // Libérer les surfaces après affichage
    SDL_FreeSurface(background);
    SDL_FreeSurface(button);
}

void display_text(const char *text, int x, int y, TTF_Font *font, SDL_Surface *screen) {
    SDL_Color textColor = {255, 255, 255}; // White text color
    SDL_Surface *message = TTF_RenderText_Solid(font, text, textColor);
    if (message) {
        SDL_Rect dest = {x, y};
        SDL_BlitSurface(message, NULL, screen, &dest);
        SDL_FreeSurface(message);
    }
}

void load_questions(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        fprintf(stderr, "Erreur d'ouverture du fichier de questions\n");
        exit(1);
    }

    char line[256];
    while (fgets(line, sizeof(line), file) && total_questions < MAX_QUESTIONS) {
        // Read question
        line[strcspn(line, "\n")] = '\0';  // Remove newline character
        strcpy(enigmes[total_questions].question, line);

        // Read answers
        for (int i = 0; i < 3; i++) {
            if (fgets(line, sizeof(line), file)) {
                line[strcspn(line, "\n")] = '\0';  // Remove newline character
                strcpy(enigmes[total_questions].answers[i], line);
            }
        }

        // Read correct answer index
        if (fgets(line, sizeof(line), file)) {
            enigmes[total_questions].correct_answer = atoi(line);
        }

        total_questions++;
    }

    fclose(file);
}

void display_random_question(TTF_Font *font, SDL_Surface *screen, int question_index) {
    if (total_questions == 0) {
        display_text("Aucune question chargée!", 50, 100, font, screen);
        return;
    }

    display_text(enigmes[question_index].question, 50, 100, font, screen);

    // Display the answers
    char answer_text[100];
    for (int i = 0; i < 3; i++) {
        sprintf(answer_text, "%d. %s", i + 1, enigmes[question_index].answers[i]);
        display_text(answer_text, 50, 150 + (i * 40), font, screen);
    }
}

void handle_input(SDL_Event *event, int *player_score, int *user_answer, int *current_question_index) {
    if (*user_answer != -1) {
        return;  // Ignore further inputs if the user already answered
    }

    int answer_index = -1;

    // Check which key was pressed and assign the answer index accordingly
    if (event->key.keysym.sym == SDLK_y) {
        answer_index = 0;
    } else if (event->key.keysym.sym == SDLK_u) {
        answer_index = 1;
    } else if (event->key.keysym.sym == SDLK_i) {
        answer_index = 2;
    }

    if (answer_index != -1) {
        // Update the user answer
        *user_answer = answer_index;

        // Check if the answer is correct and update the score
        if (enigmes[*current_question_index].correct_answer == *user_answer) {
            *player_score += 10;  // Correct answer, increase score
        } else {
            *player_score -= 5;  // Incorrect answer, decrease score
        }
    }
}


void display_score(int score, TTF_Font *font, SDL_Surface *screen) {
    char score_text[50];
    sprintf(score_text, "Score: %d", score);
    display_text(score_text, SCREEN_WIDTH - 150, 50, font, screen);
}


