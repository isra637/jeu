#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include "header.h"

#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 600
#define MAX_QUESTIONS 100

Enigme enigmes[MAX_QUESTIONS];
int total_questions = 0;

// Déclaration des sons
Mix_Chunk *correct_sound = NULL;
Mix_Chunk *wrong_sound = NULL;

// Fonction pour initialiser les sons
void init_sounds() {
    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
        fprintf(stderr, "Erreur SDL_mixer: %s\n", Mix_GetError());
        exit(1);
    }

    correct_sound = Mix_LoadWAV("correct.wav");
    wrong_sound = Mix_LoadWAV("wrong.wav");

    if (!correct_sound || !wrong_sound) {
        fprintf(stderr, "Erreur chargement sons: %s\n", Mix_GetError());
        exit(1);
    }
}

// Libération des sons
void clean_up_sounds() {
    if (correct_sound) Mix_FreeChunk(correct_sound);
    if (wrong_sound) Mix_FreeChunk(wrong_sound);
    Mix_CloseAudio();
}

// Afficher un texte
void display_text(const char *text, int x, int y, TTF_Font *font, SDL_Surface *screen) {
    SDL_Color textColor = {255, 255, 255}; // White text color
    SDL_Surface *message = TTF_RenderText_Solid(font, text, textColor);
    if (message) {
        SDL_Rect dest = {x, y};
        SDL_BlitSurface(message, NULL, screen, &dest);
        SDL_FreeSurface(message);
    }
}

// Charger les questions depuis un fichier texte
void load_questions(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        fprintf(stderr, "Erreur d'ouverture du fichier\n");
        exit(1);
    }

    char line[256];
    while (fgets(line, sizeof(line), file) && total_questions < MAX_QUESTIONS) {
        line[strcspn(line, "\n")] = '\0';  // Remove newline character
        strcpy(enigmes[total_questions].question, line);

        for (int i = 0; i < 3; i++) {
            if (fgets(line, sizeof(line), file)) {
                line[strcspn(line, "\n")] = '\0';  // Remove newline character
                strcpy(enigmes[total_questions].answers[i], line);
            }
        }

        if (fgets(line, sizeof(line), file)) {
            enigmes[total_questions].correct_answer = atoi(line);
        }

        total_questions++;
    }

    fclose(file);
}

// Afficher une question aléatoire
void display_random_question(TTF_Font *font, SDL_Surface *screen, int question_index) {
    if (total_questions == 0) {
        display_text("Aucune question chargée!", 50, 100, font, screen);
        return;
    }

    display_text(enigmes[question_index].question, 50, 100, font, screen);

    char answer_text[100];
    for (int i = 0; i < 3; i++) {
        sprintf(answer_text, "%c. %s", 'A' + i, enigmes[question_index].answers[i]);
        display_text(answer_text, 50, 150 + (i * 40), font, screen);
    }
}

// Gérer la saisie clavier
void handle_input(SDL_Event *event, int *player_score, int *user_answer, int *current_question_index) {
    if (*user_answer != -1) return; // Ignore if already answered

    int answer_index = -1;

    if (event->key.keysym.sym == SDLK_a) {
        answer_index = 0;
    } else if (event->key.keysym.sym == SDLK_b) {
        answer_index = 1;
    } else if (event->key.keysym.sym == SDLK_c) {
        answer_index = 2;
    }

    if (answer_index != -1) {
        *user_answer = answer_index;

        if (enigmes[*current_question_index].correct_answer == *user_answer) {
            *player_score += 10;
            Mix_PlayChannel(-1, correct_sound, 0);
        } else {
            *player_score -= 5;
            Mix_PlayChannel(-1, wrong_sound, 0);
        }
    }
}

// Affichage du score
void display_score(int score, TTF_Font *font, SDL_Surface *screen) {
    char score_text[50];
    sprintf(score_text, "Score: %d", score);
    display_text(score_text, SCREEN_WIDTH - 150, 50, font, screen);
}

// Affichage background + bouton
void display_background_and_button(SDL_Surface *screen) {
    SDL_Surface *background = IMG_Load("pg.png");
    if (!background) {
        fprintf(stderr, "Erreur background: %s\n", IMG_GetError());
        return;
    }

    SDL_Surface *button = IMG_Load("q.png");
    if (!button) {
        fprintf(stderr, "Erreur bouton: %s\n", IMG_GetError());
        SDL_FreeSurface(background);
        return;
    }

    SDL_BlitSurface(background, NULL, screen, NULL);

    SDL_Rect button_pos;
    button_pos.x = screen->w - button->w - 20;
    button_pos.y = screen->h - button->h - 20;
    SDL_BlitSurface(button, NULL, screen, &button_pos);

    SDL_Flip(screen);

    SDL_FreeSurface(background);
    SDL_FreeSurface(button);
}

// Fonction principale
int main() {
    int running = 1;
    SDL_Surface *screen = NULL;
    SDL_Event event;
    int player_score = 0;
    int time_left = 60;
    int user_answer = -1;
    int current_question_index = 0;

    // Initialisation SDL
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0) {
        fprintf(stderr, "Erreur SDL_Init: %s\n", SDL_GetError());
        return 1;
    }

    if (TTF_Init() == -1) {
        fprintf(stderr, "Erreur TTF_Init: %s\n", TTF_GetError());
        return 1;
    }

    screen = SDL_SetVideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, 32, SDL_SWSURFACE);
    if (!screen) {
        fprintf(stderr, "Erreur SetVideoMode: %s\n", SDL_GetError());
        return 1;
    }

    init_sounds();

    TTF_Font *font = TTF_OpenFont("/usr/share/fonts/truetype/freefont/FreeSerifBold.ttf", 24);
    if (!font) {
        fprintf(stderr, "Erreur police: %s\n", TTF_GetError());
        return 1;
    }

    load_questions("enigme.txt");

    char timer_text[50];
    char time_str[10];

    // Boucle principale
    while (running) {
        display_background_and_button(screen);
        display_random_question(font, screen, current_question_index);
        display_score(player_score, font, screen);

        if (time_left > 0) {
            // Clear previous timer text area
            SDL_Rect timer_rect = {50, 50, 200, 50};
            SDL_FillRect(screen, &timer_rect, SDL_MapRGB(screen->format, 0, 0, 0)); // Fill with black

            while (SDL_PollEvent(&event)) {
                if (event.type == SDL_QUIT)
                    running = 0;
                else if (event.type == SDL_KEYDOWN)
                    handle_input(&event, &player_score, &user_answer, &current_question_index);
            }

            sprintf(time_str, "%d", time_left);
            strcpy(timer_text, "Temps restant: ");
            strcat(timer_text, time_str);
            strcat(timer_text, " secondes");
            display_text(timer_text, 50, 50, font, screen);

            SDL_Flip(screen);
            SDL_Delay(1000);
            time_left--;
        }

        if (time_left <= 0 || user_answer != -1) {
            current_question_index++;
            if (current_question_index >= total_questions) {
                display_text("Fin du jeu!", 50, 50, font, screen);
                SDL_Flip(screen);
                SDL_Delay(2000);
                running = 0;
            } else {
                time_left = 60;
                user_answer = -1;
            }
        }
    }

    clean_up_sounds();
    TTF_CloseFont(font);
    TTF_Quit();
    SDL_Quit();
    return 0;
}

