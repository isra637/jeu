#ifndef HEADER_H
#define HEADER_H

#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>

#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 600
#define MAX_QUESTIONS 50

// Structure to hold a question and its answers
typedef struct {
    char question[256];
    char answers[3][256];  // Three possible answers
    int correct_answer;     // Index of the correct answer (0, 1, or 2)
} Enigme;

// Function declarations
void display_background_and_button(SDL_Surface *screen);
void display_text(const char *text, int x, int y, TTF_Font *font, SDL_Surface *screen);
void load_questions(const char *filename);
void display_random_question(TTF_Font *font, SDL_Surface *screen, int question_index);
void handle_input(SDL_Event *event, int *player_score, int *user_answer, int *current_question_index);
void display_score(int score, TTF_Font *font, SDL_Surface *screen);

extern Enigme enigmes[MAX_QUESTIONS];  // Array to hold all questions
extern int total_questions;            // Total number of loaded questions

#endif  // HEADER_H

